
from sqlalchemy.orm import Session
from sqlalchemy import select, desc, func
from . import models, schemas
from datetime import datetime, timezone, timedelta

# ===== Roles dinámicos =====

def ensure_default_roles(db: Session):
    defaults = ["admin", "inspector", "operario", "conductor"]
    for name in defaults:
        if not db.execute(select(models.RoleModel).where(models.RoleModel.name == name)).scalar_one_or_none():
            db.add(models.RoleModel(name=name, description=f"Rol por defecto: {name}"))
    db.commit()


def create_role(db: Session, role_in: schemas.RoleCreate) -> models.RoleModel:
    exists = db.execute(select(models.RoleModel).where(models.RoleModel.name == role_in.name)).scalar_one_or_none()
    if exists:
        raise ValueError("Ese rol ya existe")
    role = models.RoleModel(name=role_in.name, description=role_in.description)
    db.add(role)
    db.commit()
    db.refresh(role)
    return role


def list_roles(db: Session):
    return db.execute(select(models.RoleModel).order_by(models.RoleModel.name.asc())).scalars().all()


def get_role_by_name(db: Session, name: str):
    return db.execute(select(models.RoleModel).where(models.RoleModel.name == name)).scalar_one_or_none()


def assign_role_to_user(db: Session, username: str, role_name: str):
    user = get_user_by_username(db, username)
    if not user:
        raise ValueError("Usuario no encontrado")
    role = get_role_by_name(db, role_name)
    if not role:
        raise ValueError("Rol no encontrado")
    user.role_id = role.id
    db.commit()
    db.refresh(user)
    return user


def get_effective_role_name(user: models.User) -> str | None:
    if getattr(user, 'role_rel', None) is not None and user.role_rel:
        return user.role_rel.name
    if getattr(user, 'role', None) is not None:
        return user.role.value
    return None

# ===== Users =====

def get_user_by_username(db: Session, username: str):
    return db.execute(select(models.User).where(models.User.username == username)).scalar_one_or_none()


def create_user(db: Session, username: str, hashed_password: str, role_name: str | None = None):
    exists = get_user_by_username(db, username)
    if exists:
        raise ValueError("El usuario ya existe")
    user = models.User(username=username, hashed_password=hashed_password)
    if role_name:
        role = get_role_by_name(db, role_name)
        if role:
            user.role_id = role.id
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def users_count(db: Session) -> int:
    return db.execute(select(func.count(models.User.id))).scalar_one()

# ===== Passwords =====

def set_user_password_hash(db: Session, username: str, hashed_password: str):
    user = get_user_by_username(db, username)
    if not user:
        raise ValueError("Usuario no encontrado")
    user.hashed_password = hashed_password
    db.commit()
    db.refresh(user)
    return user

# ===== Assets =====

def create_asset(db: Session, asset_in: schemas.AssetCreate) -> models.Asset:
    exists = db.execute(
        select(models.Asset).where(models.Asset.code == asset_in.code)
    ).scalar_one_or_none()
    if exists:
        raise ValueError("Ya existe un activo con ese código")
    asset = models.Asset(
        type=asset_in.type,
        code=asset_in.code,
        name=asset_in.name,
        status=asset_in.status or "activo",
        metadata=asset_in.metadata,
    )
    db.add(asset)
    db.commit()
    db.refresh(asset)
    return asset


def list_assets(db: Session):
    return db.execute(select(models.Asset)).scalars().all()


def get_asset(db: Session, asset_id: str):
    return db.get(models.Asset, asset_id)

# ===== Locations =====

def get_or_create_location(db: Session, loc_in: schemas.LocationIn | None):
    if not loc_in:
        return None
    stmt = select(models.Location).where(
        models.Location.name == loc_in.name,
        models.Location.type == loc_in.type,
        models.Location.room_code == loc_in.room_code,
    )
    loc = db.execute(stmt).scalar_one_or_none()
    if loc:
        if loc_in.lat is not None:
            loc.lat = loc_in.lat
        if loc_in.lon is not None:
            loc.lon = loc_in.lon
        db.commit()
        db.refresh(loc)
        return loc
    loc = models.Location(
        name=loc_in.name,
        type=loc_in.type,
        room_code=loc_in.room_code,
        lat=loc_in.lat,
        lon=loc_in.lon,
    )
    db.add(loc)
    db.commit()
    db.refresh(loc)
    return loc

# ===== Events =====

def create_event(db: Session, ev_in: schemas.EventCreate) -> models.Event:
    asset = db.get(models.Asset, ev_in.asset_id)
    if not asset:
        raise ValueError("Activo inexistente")

    if ev_in.event_type == 'moved':
        if not ev_in.to_location:
            raise ValueError("Falta 'to_location' para evento moved")
        to_loc = get_or_create_location(db, ev_in.to_location)
        ev = models.Event(
            asset_id=asset.id,
            event_type=models.EventType.moved,
            to_location_id=to_loc.id,
            notes=ev_in.notes,
            user=ev_in.user,
        )
    elif ev_in.event_type == 'gps_ping':
        if ev_in.lat is None or ev_in.lon is None:
            raise ValueError("Faltan lat/lon para gps_ping")
        ev = models.Event(
            asset_id=asset.id,
            event_type=models.EventType.gps_ping,
            lat=ev_in.lat,
            lon=ev_in.lon,
            notes=ev_in.notes,
            user=ev_in.user,
        )
    elif ev_in.event_type == 'status_change':
        if not ev_in.status:
            raise ValueError("Falta 'status' para status_change")
        asset.status = ev_in.status
        ev = models.Event(
            asset_id=asset.id,
            event_type=models.EventType.status_change,
            notes=ev_in.notes,
            user=ev_in.user,
        )
    else:
        raise ValueError("event_type no soportado")

    db.add(ev)
    db.commit()
    db.refresh(ev)
    return ev


def asset_history(db: Session, asset_id: str):
    return db.execute(
        select(models.Event)
        .where(models.Event.asset_id == asset_id)
        .order_by(models.Event.ts.asc())
    ).scalars().all()


def asset_current(db: Session, asset_id: str):
    asset = db.get(models.Asset, asset_id)
    if not asset:
        return None
    ev = db.execute(
        select(models.Event)
        .where(models.Event.asset_id == asset_id)
        .order_by(desc(models.Event.ts))
    ).scalars().first()
    cur = {
        "asset": {
            "id": asset.id,
            "type": asset.type.value,
            "code": asset.code,
            "name": asset.name,
            "status": asset.status,
        },
        "last_event": None,
        "location": None,
    }
    if not ev:
        return cur
    cur["last_event"] = {"type": ev.event_type.value, "ts": ev.ts.isoformat()}
    if ev.event_type == models.EventType.moved:
        if ev.to_location_id:
            loc = db.get(models.Location, ev.to_location_id)
            if loc:
                cur["location"] = {
                    "name": loc.name,
                    "type": loc.type.value,
                    "room_code": loc.room_code,
                    "lat": loc.lat,
                    "lon": loc.lon,
                }
    elif ev.event_type == models.EventType.gps_ping:
        cur["location"] = {"lat": ev.lat, "lon": ev.lon}
    return cur


def kpis(db: Session):
    from collections import defaultdict
    pupitres = db.execute(select(models.Asset).where(models.Asset.type == models.AssetType.pupitre)).scalars().all()
    buses = db.execute(select(models.Asset).where(models.Asset.type == models.AssetType.bus)).scalars().all()

    def last_event(asset_id: str):
        return db.execute(
            select(models.Event)
            .where(models.Event.asset_id == asset_id)
            .order_by(desc(models.Event.ts))
        ).scalars().first()

    pupitres_en_aula = 0
    pupitres_fuera = 0
    por_ubicacion = defaultdict(int)

    for a in pupitres:
        ev = last_event(a.id)
        if ev and ev.event_type == models.EventType.moved and ev.to_location_id:
            loc = db.get(models.Location, ev.to_location_id)
            nombre = (loc.name if loc else "Desconocido")
            por_ubicacion[nombre] += 1
            if loc and loc.type == models.LocationType.aula:
                pupitres_en_aula += 1
            else:
                pupitres_fuera += 1
        else:
            pupitres_fuera += 1

    total_pupitres = len(pupitres)
    ocupacion_pupitres = (pupitres_en_aula / total_pupitres * 100) if total_pupitres else 0.0

    now = datetime.now(timezone.utc)
    buses_online = 0
    for b in buses:
        ev = last_event(b.id)
        if ev and ev.event_type == models.EventType.gps_ping and (now - ev.ts) <= timedelta(minutes=5):
            buses_online += 1
    total_buses = len(buses)

    return {
        "pupitres": {
            "total": total_pupitres,
            "en_aula": pupitres_en_aula,
            "fuera": pupitres_fuera,
            "ocupacion_en_aula_pct": round(ocupacion_pupitres, 2),
            "por_ubicacion": dict(sorted(por_ubicacion.items(), key=lambda x: x[0]))
        },
        "buses": {
            "total": total_buses,
            "online_ult_5min": buses_online,
            "offline": total_buses - buses_online
        }
    }
