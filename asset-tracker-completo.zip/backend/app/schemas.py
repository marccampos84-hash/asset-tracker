
from pydantic import BaseModel
from typing import Optional, Literal
from datetime import datetime

# Locations
class LocationIn(BaseModel):
    name: str
    type: Literal['aula','almacen','cochera','ruta','otro'] = 'otro'
    room_code: Optional[str] = None
    lat: Optional[float] = None
    lon: Optional[float] = None

# Assets
class AssetBase(BaseModel):
    type: Literal['pupitre','bus']
    code: str
    name: str
    status: Optional[str] = 'activo'
    metadata: Optional[dict] = None

class AssetCreate(AssetBase):
    pass

class Asset(BaseModel):
    id: str
    type: Literal['pupitre','bus']
    code: str
    name: str
    status: Optional[str]
    metadata: Optional[dict]
    class Config:
        from_attributes = True

# Events
class EventBase(BaseModel):
    asset_id: str
    event_type: Literal['moved','gps_ping','status_change']
    notes: Optional[str] = None
    user: Optional[str] = None

class EventCreate(EventBase):
    to_location: Optional[LocationIn] = None  # para moved
    lat: Optional[float] = None  # para gps_ping
    lon: Optional[float] = None
    status: Optional[str] = None  # para status_change

class Event(BaseModel):
    id: str
    asset_id: str
    event_type: str
    ts: datetime
    notes: Optional[str] = None
    user: Optional[str] = None
    class Config:
        from_attributes = True

# Roles dinámicos
class RoleCreate(BaseModel):
    name: str
    description: Optional[str] = None

class RoleOut(BaseModel):
    id: str
    name: str
    description: Optional[str] = None
    class Config:
        from_attributes = True

class AssignRoleRequest(BaseModel):
    role_name: str

# Users & Auth
class UserCreate(BaseModel):
    username: str
    password: str
    role_name: Optional[str] = None

class User(BaseModel):
    id: str
    username: str
    is_active: bool
    role_name: Optional[str] = None
    class Config:
        from_attributes = True

class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    username: Optional[str] = None

# Password change
class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str

class AdminResetPasswordRequest(BaseModel):
    new_password: str
