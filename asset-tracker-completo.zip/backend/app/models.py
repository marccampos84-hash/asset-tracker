
from sqlalchemy import Column, String, Enum, DateTime, ForeignKey, Float, Text, JSON, Boolean
from sqlalchemy.orm import relationship
from .database import Base
import enum
import uuid
from datetime import datetime, timezone

# Enum legacy (compatibilidad)
class Role(str, enum.Enum):
    admin = "admin"
    inspector = "inspector"
    operario = "operario"
    conductor = "conductor"

class AssetType(str, enum.Enum):
    pupitre = "pupitre"
    bus = "bus"

class LocationType(str, enum.Enum):
    aula = "aula"
    almacen = "almacen"
    cochera = "cochera"
    ruta = "ruta"
    otro = "otro"

class EventType(str, enum.Enum):
    moved = "moved"
    gps_ping = "gps_ping"
    status_change = "status_change"

class RoleModel(Base):
    __tablename__ = "roles"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String, unique=True, nullable=False, index=True)
    description = Column(Text, nullable=True)

class User(Base):
    __tablename__ = "users"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    username = Column(String, unique=True, nullable=False, index=True)
    hashed_password = Column(String, nullable=False)
    role = Column(Enum(Role), nullable=True)  # legacy opcional
    role_id = Column(String, ForeignKey("roles.id"), nullable=True)
    role_rel = relationship("RoleModel")
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

class Asset(Base):
    __tablename__ = "assets"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    type = Column(Enum(AssetType), nullable=False)
    code = Column(String, unique=True, nullable=False)
    name = Column(String, nullable=False)
    status = Column(String, default="activo")
    metadata = Column(JSON, nullable=True)

    events = relationship("Event", back_populates="asset", cascade="all, delete-orphan")

class Location(Base):
    __tablename__ = "locations"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String, nullable=False)
    type = Column(Enum(LocationType), nullable=False, default=LocationType.otro)
    room_code = Column(String, nullable=True)
    lat = Column(Float, nullable=True)
    lon = Column(Float, nullable=True)

class Event(Base):
    __tablename__ = "events"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    asset_id = Column(String, ForeignKey("assets.id"), nullable=False)
    event_type = Column(Enum(EventType), nullable=False)
    ts = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)

    from_location_id = Column(String, ForeignKey("locations.id"), nullable=True)
    to_location_id = Column(String, ForeignKey("locations.id"), nullable=True)

    lat = Column(Float, nullable=True)
    lon = Column(Float, nullable=True)
    notes = Column(Text, nullable=True)
    user = Column(String, nullable=True)

    asset = relationship("Asset", back_populates="events")
