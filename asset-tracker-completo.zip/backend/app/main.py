
from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from . import models, schemas, crud, database, security
from datetime import datetime, timezone, timedelta

models.Base.metadata.create_all(bind=database.engine)

app = FastAPI(title="Asset Tracker: Pupitres y Autobuses")

# Dependency

def get_db():
    db = database.SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.on_event("startup")
def on_startup():
    models.Base.metadata.create_all(bind=database.engine)
    with database.SessionLocal() as db:
        crud.ensure_default_roles(db)

@app.get("/health")
def health():
    return {"status": "ok", "time": datetime.now(timezone.utc).isoformat()}

# =============== AUTH ===============
@app.post("/auth/signup", response_model=schemas.User)
def signup(user_in: schemas.UserCreate, db: Session = Depends(get_db)):
    total = crud.users_count(db)
    if total > 0:
        raise HTTPException(status_code=403, detail="Usa /auth/admin/create_user (requiere admin)")
    crud.ensure_default_roles(db)
    role_name = user_in.role_name or 'admin'
    if role_name.lower() != 'admin':
        role_name = 'admin'
    user = crud.create_user(
        db,
        username=user_in.username,
        hashed_password=security.get_password_hash(user_in.password),
        role_name=role_name
    )
    return to_user_schema(user)

@app.post("/auth/admin/create_user", response_model=schemas.User)
def admin_create_user(user_in: schemas.UserCreate, db: Session = Depends(get_db), _admin = Depends(security.require_roles('admin'))):
    if user_in.role_name:
        crud.ensure_default_roles(db)
    user = crud.create_user(
        db,
        username=user_in.username,
        hashed_password=security.get_password_hash(user_in.password),
        role_name=(user_in.role_name or None)
    )
    return to_user_schema(user)

@app.post("/auth/login", response_model=schemas.Token)
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = crud.get_user_by_username(db, form_data.username)
    if not user or not security.verify_password(form_data.password, user.hashed_password):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Credenciales inválidas")
    role_name = crud.get_effective_role_name(user) or ""
    access_token_expires = timedelta(minutes=security.ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = security.create_access_token(
        data={"sub": user.username, "role": role_name},
        expires_delta=access_token_expires,
    )
    return {"access_token": access_token, "token_type": "bearer"}

@app.get("/auth/me", response_model=schemas.User)
def me(current_user = Depends(security.get_current_active_user)):
    return to_user_schema(current_user)

# ---- Gestión de roles (admin) ----
@app.post("/auth/admin/roles", response_model=schemas.RoleOut)
def create_role(role_in: schemas.RoleCreate, db: Session = Depends(get_db), _admin = Depends(security.require_roles('admin'))):
    try:
        role = crud.create_role(db, role_in)
        return role
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/auth/admin/roles", response_model=list[schemas.RoleOut])
def list_all_roles(db: Session = Depends(get_db), _admin = Depends(security.require_roles('admin'))):
    return crud.list_roles(db)

@app.post("/auth/admin/users/{username}/role", response_model=schemas.User)
def assign_role(username: str, req: schemas.AssignRoleRequest, db: Session = Depends(get_db), _admin = Depends(security.require_roles('admin'))):
    try:
        user = crud.assign_role_to_user(db, username, req.role_name)
        return to_user_schema(user)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

# ---- Password management ----
@app.post("/auth/change_password")
def change_password(payload: schemas.ChangePasswordRequest, db: Session = Depends(get_db), current_user = Depends(security.get_current_active_user)):
    if not security.verify_password(payload.current_password, current_user.hashed_password):
        raise HTTPException(status_code=400, detail="La contraseña actual no es correcta")
    if len(payload.new_password) < 8:
        raise HTTPException(status_code=400, detail="La nueva contraseña debe tener al menos 8 caracteres")
    hashed = security.get_password_hash(payload.new_password)
    from . import crud as crud_mod
    crud_mod.set_user_password_hash(db, current_user.username, hashed)
    return {"status": "ok"}

@app.post("/auth/admin/users/{username}/reset_password")
def admin_reset_password(username: str, payload: schemas.AdminResetPasswordRequest, db: Session = Depends(get_db), _admin = Depends(security.require_roles('admin'))):
    if len(payload.new_password) < 8:
        raise HTTPException(status_code=400, detail="La nueva contraseña debe tener al menos 8 caracteres")
    hashed = security.get_password_hash(payload.new_password)
    try:
        from . import crud as crud_mod
        user = crud_mod.set_user_password_hash(db, username, hashed)
        return {"status": "ok", "username": user.username}
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))

# =============== ASSETS ===============
@app.post("/assets", response_model=schemas.Asset)
def create_asset(asset_in: schemas.AssetCreate, db: Session = Depends(get_db), _user = Depends(security.require_roles('admin'))):
    return crud.create_asset(db, asset_in)

@app.get("/assets", response_model=list[schemas.Asset])
def list_assets(db: Session = Depends(get_db), _user = Depends(security.get_current_active_user)):
    return crud.list_assets(db)

@app.get("/assets/{asset_id}", response_model=schemas.Asset)
def get_asset(asset_id: str, db: Session = Depends(get_db), _user = Depends(security.get_current_active_user)):
    asset = crud.get_asset(db, asset_id)
    if not asset:
        raise HTTPException(status_code=404, detail="Activo no encontrado")
    return asset

# =============== EVENTS ===============
@app.post("/events", response_model=schemas.Event)
def create_event(ev_in: schemas.EventCreate, db: Session = Depends(get_db), current_user = Depends(security.require_roles('admin','operario','conductor','editor'))):
    if not ev_in.user:
        ev_in.user = getattr(current_user, 'username', None)
    try:
        return crud.create_event(db, ev_in)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/assets/{asset_id}/history", response_model=list[schemas.Event])
def asset_history(asset_id: str, db: Session = Depends(get_db), _user = Depends(security.get_current_active_user)):
    return crud.asset_history(db, asset_id)

@app.get("/assets/{asset_id}/current")
def asset_current(asset_id: str, db: Session = Depends(get_db), _user = Depends(security.get_current_active_user)):
    cur = crud.asset_current(db, asset_id)
    if not cur:
        raise HTTPException(status_code=404, detail="Activo no encontrado")
    return cur

@app.get("/kpis")
def kpis(db: Session = Depends(get_db), _user = Depends(security.get_current_active_user)):
    return crud.kpis(db)

# ===== helpers =====

def to_user_schema(user: models.User) -> schemas.User:
    return schemas.User(
        id=user.id,
        username=user.username,
        is_active=user.is_active,
        role_name=crud.get_effective_role_name(user)
    )
