#!/usr/bin/env bash
set -euo pipefail

# =============================================================
# Elevar a 'admin' al usuario Marc
# Crea el usuario si no existe y le asigna rol 'admin'.
#
# Requisitos:
#   BASE_URL: http://localhost:8000 (o el tuyo)
#   ADMIN_TOKEN: token Bearer de un admin actual (si no hay admin aún, usa /auth/signup)
#   MARC_USERNAME: por defecto 'marc' (cámbialo si usas otro)
#   MARC_PASSWORD: solo si hay que crearlo (temporal)
#
# Uso:
#   BASE_URL=http://localhost:8000 ADMIN_TOKEN=ey... ./scripts/make_marc_admin.sh
#   (Opcional) export MARC_USERNAME=marc; export MARC_PASSWORD='Temp!2026'
# =============================================================

: "${BASE_URL:?Debes exportar BASE_URL, p.ej.: BASE_URL=http://localhost:8000}"
: "${ADMIN_TOKEN:?Debes exportar ADMIN_TOKEN (Bearer token de un admin o crea el primer admin con /auth/signup)}"

MARC_USERNAME="${MARC_USERNAME:-marc}"
MARC_PASSWORD="${MARC_PASSWORD:-Temp!2026}"

HDR_AUTH=( -H "Authorization: Bearer ${ADMIN_TOKEN}" )
HDR_JSON=( -H "Content-Type: application/json" )

# intenta crear al usuario (si ya existe, ignora el error)
echo "[INFO] Creando usuario '${MARC_USERNAME}' si no existe" >&2
curl -sS -X POST "${BASE_URL}/auth/admin/create_user" \
  "${HDR_AUTH[@]}" "${HDR_JSON[@]}" \
  -d "{\"username\":\"${MARC_USERNAME}\",\"password\":\"${MARC_PASSWORD}\"}" >/dev/null || true

# asignar rol admin
echo "[INFO] Asignando rol 'admin' a '${MARC_USERNAME}'" >&2
curl -sS -X POST "${BASE_URL}/auth/admin/users/${MARC_USERNAME}/role" \
  "${HDR_AUTH[@]}" "${HDR_JSON[@]}" \
  -d '{"role_name":"admin"}' | jq -r '.role_name' || true

echo "[OK] Usuario '${MARC_USERNAME}' es administrador (admin)."
