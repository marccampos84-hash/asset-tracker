#!/usr/bin/env bash
set -euo pipefail

# =============================================================
# Asignación de roles personalizados para Asset Tracker
# - Crea roles si no existen
# - Crea usuarios (si faltan) con contraseña temporal
# - Asigna role_name a cada usuario
# - **Asegura que Marc sea ADMIN** (al final)
#
# Requisitos:
#   - BASE_URL: URL base del backend (ej: http://localhost:8000)
#   - ADMIN_TOKEN: token Bearer de un usuario admin
#
# Uso:
#   BASE_URL=http://localhost:8000 ADMIN_TOKEN=ey... ./scripts/assign_roles.sh
#   Variables opcionales:
#     MARC_USERNAME (por defecto: marc)
#     MARC_PASSWORD (para crear si no existe; por defecto: Temp!2026)
# =============================================================

: "${BASE_URL:?Debes exportar BASE_URL, p.ej.: BASE_URL=http://localhost:8000}"
: "${ADMIN_TOKEN:?Debes exportar ADMIN_TOKEN (Bearer token de un admin)}"

MARC_USERNAME="${MARC_USERNAME:-marc}"
MARC_PASSWORD="${MARC_PASSWORD:-Temp!2026}"

HDR_AUTH=( -H "Authorization: Bearer ${ADMIN_TOKEN}" )
HDR_JSON=( -H "Content-Type: application/json" )

require_tool(){ command -v "$1" >/dev/null 2>&1 || { echo "[ERROR] Falta '$1'. Instálalo y vuelve a ejecutar."; exit 1; }; }
require_tool curl
require_tool jq

# --- helpers ---
create_role(){
  local name="$1"; shift
  local desc="$*"
  echo "[INFO] Creando rol '${name}' (si no existe)" >&2
  curl -sS -X POST "${BASE_URL}/auth/admin/roles" \
    "${HDR_AUTH[@]}" "${HDR_JSON[@]}" \
    -d "{\"name\":\"${name}\",\"description\":\"${desc}\"}" \
    | jq -r '.id? // empty' >/dev/null || true
}

create_user_if_missing(){
  local username="$1"; local password="$2"
  echo "[INFO] Creando usuario '${username}' si no existe" >&2
  curl -sS -X POST "${BASE_URL}/auth/admin/create_user" \
    "${HDR_AUTH[@]}" "${HDR_JSON[@]}" \
    -d "{\"username\":\"${username}\",\"password\":\"${password}\"}" \
    | jq -r '.id? // empty' >/dev/null || true
}

assign_role(){
  local username="$1"; local role_name="$2"
  echo "[INFO] Asignando rol '${role_name}' a '${username}'" >&2
  curl -sS -X POST "${BASE_URL}/auth/admin/users/${username}/role" \
    "${HDR_AUTH[@]}" "${HDR_JSON[@]}" \
    -d "{\"role_name\":\"${role_name}\"}" \
    | jq -r '.role_name? // empty' >/dev/null
}

echo "[INFO] Base URL: ${BASE_URL}"

# 1) Asegurar roles necesarios
create_role solo_lectura "Acceso de solo lectura a activos, historial y KPIs"
create_role editor "Puede crear eventos (mover pupitres, gps_ping), ver activos e indicadores"
create_role admin "Administrador total"

# 2) Usuarios y asignaciones
TMP_PASS='Temp!2026'

# Solo lectura
create_user_if_missing josep.quesada   "$TMP_PASS"
assign_role            josep.quesada   solo_lectura

create_user_if_missing cesar.torres    "$TMP_PASS"
assign_role            cesar.torres    solo_lectura

# Editores
create_user_if_missing roberto         "$TMP_PASS"
assign_role            roberto         editor

create_user_if_missing alex.c          "$TMP_PASS"
assign_role            alex.c          editor

create_user_if_missing alex.m          "$TMP_PASS"
assign_role            alex.m          editor

create_user_if_missing miguel.angel    "$TMP_PASS"
assign_role            miguel.angel    editor

create_user_if_missing pedro           "$TMP_PASS"
assign_role            pedro           editor

create_user_if_missing isaac           "$TMP_PASS"
assign_role            isaac           editor

# 3) Asegurar que Marc es ADMIN
create_user_if_missing "${MARC_USERNAME}" "$MARC_PASSWORD"
assign_role            "${MARC_USERNAME}" admin

echo "[OK] Roles creados y asignados. '${MARC_USERNAME}' es ADMIN."
