# Asset Tracker: Pupitres y Autobuses (MVP) — Auth + Roles + Password Reset

Aplicación FastAPI para **controlar pupitres y autobuses**, con **historial**, **ubicación actual** y **autenticación JWT** con **roles personalizados**. Incluye rutas para **cambio de contraseña**, **gestión de roles** y **scripts** para crear usuarios y asignar roles.

> Estado: MVP funcional. Base de datos SQLite para pruebas. Se puede migrar a PostgreSQL/Supabase.

## 🧱 Stack
- FastAPI, Pydantic v2
- SQLAlchemy 2.x + SQLite (local)
- JWT (python-jose) + Hash de contraseñas (passlib[bcrypt])
- GitHub Actions (tests básicos)

## 🚀 Puesta en marcha (local)

```bash
cd asset-tracker
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scriptsctivate
pip install -r backend/requirements.txt
uvicorn backend.app.main:app --reload --port 8000
```

Abrir la documentación: http://localhost:8000/docs

### Variables de entorno (opcionales)
Crea un `.env` o exporta antes de arrancar:
```bash
SECRET_KEY=clave-super-secreta
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=90
```

## 🔐 Autenticación y Roles

### Endpoints Auth
- `POST /auth/signup` → Crea el **primer usuario** como **admin** (si aún no hay usuarios).
- `POST /auth/admin/create_user` → Crea usuarios (requiere admin).
- `POST /auth/login` → Devuelve `access_token` (Bearer).
- `GET /auth/me` → Info del usuario autenticado.
- `POST /auth/change_password` → Usuario cambia su propia contraseña.
- `POST /auth/admin/users/{username}/reset_password` → Admin resetea contraseña de un usuario.

### Roles personalizados
- `POST /auth/admin/roles` → Crear rol (admin).
- `GET  /auth/admin/roles` → Listar roles (admin).
- `POST /auth/admin/users/{username}/role` → Asignar rol a usuario (admin).

> Roles por defecto creados al arrancar: `admin`, `inspector`, `operario`, `conductor`.

### Permisos por rol (por defecto)
- `admin`: todo + gestión de usuarios/roles.
- `editor`: **puede crear eventos** (mover pupitres, `gps_ping`) y leer.
- `solo_lectura`: solo lectura (activos, historial, estado, KPIs).

> Puedes ajustar permisos editando `security.require_roles(...)` en `backend/app/main.py`.

## 📦 Endpoints de negocio
- `POST /assets` (**admin**): crear activo (`pupitre` | `bus`).
- `GET /assets` (auth): listar activos.
- `GET /assets/{asset_id}` (auth): detalle.
- `POST /events` (**admin/operario/conductor/editor**): registrar evento (`moved`, `gps_ping`, `status_change`).
- `GET /assets/{asset_id}/history` (auth): historial.
- `GET /assets/{asset_id}/current` (auth): última ubicación/estado.
- `GET /kpis` (auth): KPIs de ocupación y disponibilidad.

## 🗃️ Modelos (resumen)
- `users(id, username, hashed_password, role(enum, opcional), role_id -> roles.id, is_active)`
- `roles(id, name, description)`
- `assets(id, type[pupitre|bus], code, name, status, metadata)`
- `locations(id, name, type, room_code, lat, lon)`
- `events(id, asset_id, event_type[moved|gps_ping|status_change], ts, to_location_id, lat, lon, notes, user)`

## 🧩 Scripts incluidos (en `/scripts`)

### 1) `assign_roles.sh`
Crea roles `solo_lectura`, `editor`, `admin` si faltan; crea usuarios del equipo y asigna roles; **asegura que Marc sea `admin`**.

Uso:
```bash
chmod +x scripts/assign_roles.sh
export BASE_URL="http://localhost:8000"
export ADMIN_TOKEN="<TOKEN_ADMIN>"
# Opcionales
export MARC_USERNAME="marc"
export MARC_PASSWORD="Temp!2026"

scripts/assign_roles.sh
```

### 2) `make_marc_admin.sh`
Sólo asegura que Marc sea admin (crea usuario si no existe y asigna `admin`).

Uso:
```bash
chmod +x scripts/make_marc_admin.sh
export BASE_URL="http://localhost:8000"
export ADMIN_TOKEN="<TOKEN_ADMIN>"
# Opcionales
export MARC_USERNAME="marc"
export MARC_PASSWORD="Temp!2026"

scripts/make_marc_admin.sh
```

## 🔁 Despliegue
1. Crea un repositorio en GitHub y sube este proyecto.
2. GitHub Actions (`.github/workflows/ci.yml`) lanza tests básicos.
3. Despliega en Render/Railway/Fly.io/Azure App Service (configura `SECRET_KEY`).

## ✅ Checklist rápido
- [ ] Arrancar backend
- [ ] Crear primer admin con `/auth/signup` (si no existe ninguno)
- [ ] Ejecutar `scripts/assign_roles.sh`
- [ ] Probar login y `GET /auth/me`
- [ ] Probar crear eventos con un usuario `editor`
